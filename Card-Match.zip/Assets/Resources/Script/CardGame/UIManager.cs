using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    [SerializeField] private Text correctGuessText;
    [SerializeField] private Text totalGuessText;
    [SerializeField] private GameObject gameCompletedUI;

    public void UpdateUI(int correctGuessCount, int totalGuessCount)
    {
        correctGuessText.text = $"Correct Guesses: {correctGuessCount}";
        totalGuessText.text = $"Total Guesses: {totalGuessCount}";
    }

    public void ShowGameCompletedUI()
    {
        gameCompletedUI.SetActive(true);
    }
}