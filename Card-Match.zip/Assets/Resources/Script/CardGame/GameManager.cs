using System.Collections;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private int guessCorrectCount;

    [SerializeField] private CardManager cardManager;
    [SerializeField] private UIManager uiManager;
    [SerializeField] private PersistenceManager persistenceManager;

    private int firstGuessIndex = -1;
    private int secondGuessIndex = -1;
    private int correctGuessCount;
    private int totalGuessCount;
    private int gameGuessCount;

    private void Start()
    {
        int maxCardValue = 8; // Set the desired maximum card value
        cardManager.CreateCards(maxCardValue);
        cardManager.AddCardPuzzles();
        cardManager.ShuffleCards();
        cardManager.SetCardsToButtons();
        uiManager.UpdateUI(correctGuessCount, totalGuessCount);

        gameGuessCount = 8 / 2; //CardPuzzle2D List
    }

    public void HandleCardClick(int cardIndex)
    {
        if (firstGuessIndex == -1)
        {
            firstGuessIndex = cardIndex;
            // Show the first card
        }
        else if (secondGuessIndex == -1)
        {
            secondGuessIndex = cardIndex;
            totalGuessCount++;
            uiManager.UpdateUI(correctGuessCount, totalGuessCount);

            // Check for a match
            if (/* Cards match */)
            {
                correctGuessCount++;
                firstGuessIndex = -1;
                secondGuessIndex = -1;
                uiManager.UpdateUI(correctGuessCount, totalGuessCount);

                if (correctGuessCount == /* Maximum correct guesses */)
                {
                    // Game completed
                    uiManager.ShowGameCompletedUI();
                }
            }
            else
            {
                // Cards don't match, hide cards after a delay
                StartCoroutine(HideCardsAfterDelay());
            }
        }
    }

    private void checkGameFinish()
    {
        guessCorrectCount++;
        persistenceManager.setCorrectGuessCount(guessCorrectCount);
        persistenceManager.getCorrectGuessCount();


        if (guessCorrectCount == gameGuessCount)
        {
            SoundManager.Instance.PlayGameFinishSound();
            uiManager.ShowGameCompletedUI();
            Debug.Log("Game is finished");
            Debug.Log("It took you " + gameGuessCount + " to finish the game");
        }
    }

    private IEnumerator HideCardsAfterDelay()
    {
        yield return new WaitForSeconds(1f); // Delay of 1 second
        // Hide the cards
        firstGuessIndex = -1;
        secondGuessIndex = -1;
    }
}