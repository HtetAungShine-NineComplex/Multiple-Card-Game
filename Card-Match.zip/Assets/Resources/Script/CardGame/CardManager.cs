using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardManager : MonoBehaviour
{
    [SerializeField] private Sprite cardBackgroundSprite;
    [SerializeField] private List<Sprite> puzzleSprites;
    [SerializeField] private Button cardButtonPrefab;
    [SerializeField] private Transform cardParentTransform;

    private List<Button> cardButtons = new List<Button>();
    private List<Sprite> cardPuzzles = new List<Sprite>();

    public void CreateCards(int maxCardValue)
    {
        for (int i = 0; i < maxCardValue; i++)
        {
            Button card = Instantiate(cardButtonPrefab, cardParentTransform);
            card.GetComponent<Image>().sprite = cardBackgroundSprite;
            cardButtons.Add(card);
        }
    }

    public void AddCardPuzzles()
    {
        int looper = cardButtons.Count;
        int index = 0;

        for (int i = 0; i < looper; i++)
        {
            if (index == looper / 2)
            {
                index = 0;
            }
            cardPuzzles.Add(puzzleSprites[index]);
            index++;
        }
    }

    public void ShuffleCards()
    {
        // Implement card shuffling logic here
    }

    public void SetCardsToButtons()
    {
        for (int i = 0; i < cardButtons.Count; i++)
        {
            cardButtons[i].GetComponent<Image>().sprite = cardPuzzles[i];
        }
    }

    // Other card management methods...
}