using UnityEngine;

public class PersistenceManager : MonoBehaviour
{
    // Methods for saving and loading game data
    public void SaveGameData(/* Game data */)
    {
        // Save game data to PlayerPrefs or a file
    }

    public void LoadGameData(/* Game data */)
    {
        // Load game data from PlayerPrefs or a file
    }

    private void setCorrectGuessCount(int _guessCorrectCount)
    {
        PlayerPrefs.SetInt("CorrectGuessCount", _guessCorrectCount);
    }
    private void getCorrectGuessCount()
    {
        //PlayerPrefs.GetInt("CorrectGuessCount");
        guessCorrectCount = PlayerPrefs.GetInt("CorrectGuessCount");
        correctGuess_Txt.text = guessCorrectCount.ToString();
    }
}